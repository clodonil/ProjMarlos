CREATE DATABASE IF NOT EXISTS
    programadorabordo;
USE programadorabordo;

CREATE TABLE IF NOT EXISTS products (
    id INT(11) AUTO_INCREMENT,
    name VARCHAR(255),
    price DECIMAL(10, 2),
    PRIMARY KEY (id)
);

INSERT INTO products VALUE(0, 'Curso Front-end especialista', 250);
INSERT INTO products VALUE(0, 'Curso JS Fullstack', 900);
INSERT INTO products VALUE(0, 'Curso Docker', 500);
INSERT INTO products VALUE(0, 'Curso Desenho docker', 1400000);
